# 🔧 Integration Examples for Different Platforms

## 🌐 Static Hosting Platforms

### Vercel
```json
// vercel.json
{
  "routes": [
    { "handle": "filesystem" },
    { "src": "/(.*)", "status": 404, "dest": "/404.html" }
  ]
}
```
Then rename `index.html` to `404.html` in your public folder.

### Netlify
```toml
# netlify.toml
[[redirects]]
  from = "/*"
  to = "/404.html"
  status = 404
```

### GitHub Pages
Simply rename `index.html` to `404.html` in your repository root.

## 🖥️ Server Configurations

### Apache
```apache
# .htaccess
ErrorDocument 404 /portable-404/index.html

# Or for root level
ErrorDocument 404 /404.html
```

### Nginx
```nginx
# nginx.conf
server {
    error_page 404 /portable-404/index.html;
    
    location = /portable-404/index.html {
        internal;
    }
}
```

### Express.js
```javascript
// Basic setup
app.use((req, res) => {
  res.status(404).sendFile(__dirname + '/public/portable-404/index.html');
});

// With custom routing
app.get('*', (req, res) => {
  res.status(404).sendFile(path.join(__dirname, 'portable-404', 'index.html'));
});
```

## ⚛️ Framework Integration

### Next.js (App Router)
```typescript
// app/not-found.tsx
import fs from 'fs';
import path from 'path';

export default function NotFound() {
  // Option 1: Redirect to static file
  // return redirect('/404.html');
  
  // Option 2: Inline the HTML (recommended)
  const html404 = fs.readFileSync(
    path.join(process.cwd(), 'portable-404', 'index.html'), 
    'utf8'
  );
  
  return <div dangerouslySetInnerHTML={{ __html: html404 }} />;
}
```

### Next.js (Pages Router)
```javascript
// pages/404.js
import { GetStaticProps } from 'next';

export default function Custom404({ html404 }) {
  return <div dangerouslySetInnerHTML={{ __html: html404 }} />;
}

export const getStaticProps: GetStaticProps = async () => {
  const fs = require('fs');
  const path = require('path');
  
  const html404 = fs.readFileSync(
    path.join(process.cwd(), 'portable-404', 'index.html'),
    'utf8'
  );
  
  return {
    props: { html404 }
  };
};
```

### React (Create React App)
```javascript
// public/404.html (copy the index.html content)
// CRA automatically serves 404.html for unknown routes

// Or in App.js for client-side routing
import { BrowserRouter, Routes, Route } from 'react-router-dom';

function Custom404() {
  useEffect(() => {
    // Load the 404 page content
    fetch('/portable-404/index.html')
      .then(res => res.text())
      .then(html => {
        document.body.innerHTML = html;
      });
  }, []);
  
  return null;
}

function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Your routes */}
        <Route path="*" element={<Custom404 />} />
      </Routes>
    </BrowserRouter>
  );
}
```

### Vue.js
```javascript
// router/index.js
const routes = [
  // Your routes
  {
    path: '/:pathMatch(.*)*',
    name: 'NotFound',
    component: () => import('@/views/404.vue')
  }
];

// views/404.vue
<template>
  <div v-html="html404"></div>
</template>

<script>
export default {
  data() {
    return {
      html404: ''
    };
  },
  async mounted() {
    const response = await fetch('/portable-404/index.html');
    this.html404 = await response.text();
  }
};
</script>
```

### Angular
```typescript
// app-routing.module.ts
const routes: Routes = [
  // Your routes
  { path: '**', component: NotFoundComponent }
];

// not-found.component.ts
import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-not-found',
  template: '<div [innerHTML]="html404"></div>'
})
export class NotFoundComponent implements OnInit {
  html404: string = '';

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.http.get('/portable-404/index.html', { responseType: 'text' })
      .subscribe(html => this.html404 = html);
  }
}
```

## 🐳 Docker/Container Setup

### Dockerfile
```dockerfile
# Copy 404 page to nginx
COPY portable-404/ /usr/share/nginx/html/portable-404/

# Custom nginx config
COPY nginx.conf /etc/nginx/nginx.conf
```

### nginx.conf for containers
```nginx
server {
    listen 80;
    root /usr/share/nginx/html;
    
    # Serve 404 page
    error_page 404 /portable-404/index.html;
    
    location / {
        try_files $uri $uri/ =404;
    }
}
```

## 📱 CDN Integration

### Cloudflare
```javascript
// Cloudflare Workers
addEventListener('fetch', event => {
  event.respondWith(handleRequest(event.request));
});

async function handleRequest(request) {
  const response = await fetch(request);
  
  if (response.status === 404) {
    const html404 = await fetch('https://your-cdn.com/portable-404/index.html');
    return new Response(await html404.text(), {
      status: 404,
      headers: { 'Content-Type': 'text/html' }
    });
  }
  
  return response;
}
```

### AWS S3 + CloudFront
```json
// S3 bucket website configuration
{
  "ErrorDocument": {
    "Key": "portable-404/index.html"
  }
}
```

## 🔍 Testing Your Setup

### Local Testing
```bash
# Test with Python
python -m http.server 8000
# Visit http://localhost:8000/nonexistent

# Test with Node.js (serve)
npx serve .
# Visit http://localhost:3000/nonexistent
```

### Curl Testing
```bash
# Test 404 response
curl -I http://your-domain.com/nonexistent

# Should return 404 status
HTTP/1.1 404 Not Found
```

## ⚡ Performance Tips

1. **Enable Gzip Compression**
```nginx
gzip on;
gzip_types text/html text/css application/javascript;
```

2. **Add Cache Headers**
```apache
<FilesMatch "\.html$">
    ExpiresActive On
    ExpiresDefault "access plus 1 hour"
</FilesMatch>
```

3. **Preload Critical Resources**
```html
<link rel="preload" href="lost.gif" as="image">
```

## 📊 Analytics Integration

### Google Analytics
```html
<!-- Add before closing </body> tag -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'GA_MEASUREMENT_ID');
  
  // Track 404 events
  gtag('event', 'page_view', {
    page_title: '404 Error',
    page_location: window.location.href
  });
</script>
```

### Track Game Interactions
```javascript
// Add to the game functions
function startGame() {
  // Existing code...
  
  // Track game start
  if (typeof gtag !== 'undefined') {
    gtag('event', 'game_start', {
      event_category: '404_game',
      event_label: 'megapede'
    });
  }
}
```

This should cover most integration scenarios! The package is designed to be as portable as possible while maintaining all the AquaPrime branding and features.
# 🎮 Portable AquaPrime 404 Page with Hidden Megapede Game

A self-contained, framework-agnostic 404 page that can be dropped into any website. Features the lost ARI platypus and a hidden Megapede game!

## 🚀 Quick Setup

### Option 1: Single File (Easiest)
Just use `index.html` - it's completely self-contained with embedded CSS and JavaScript.

### Option 2: With Assets
1. Copy the entire `portable-404/` folder to your website
2. Update the lost ARI gif path in the HTML file
3. Point your 404 error page to `index.html`

## 📁 File Structure

```
portable-404/
├── index.html          # Main 404 page (self-contained)
├── lost.gif           # Lost ARI platypus animation
└── README.md          # This file
```

## 🔧 Integration Examples

### Apache (.htaccess)
```apache
ErrorDocument 404 /portable-404/index.html
```

### Nginx
```nginx
error_page 404 /portable-404/index.html;
```

### Next.js
```javascript
// pages/404.js or app/not-found.tsx
export default function Custom404() {
  // Include the HTML content or redirect to static file
}
```

### Express.js
```javascript
app.use((req, res) => {
  res.status(404).sendFile(__dirname + '/portable-404/index.html');
});
```

### Static Hosting (Vercel, Netlify, etc.)
Just rename `index.html` to `404.html` in your public folder.

## 🎯 Features

- ✅ **Lost ARI Animation** - Cute confused platypus
- ✅ **Ocean-themed messaging** - AquaPrime branding
- ✅ **Hidden Megapede Game** - Click "404" badge 7 times
- ✅ **Responsive Design** - Works on desktop and mobile
- ✅ **Self-contained** - No external dependencies
- ✅ **Framework Agnostic** - Works with any backend/frontend
- ✅ **Lightweight** - ~15KB single file

## 🎮 Game Features

- Classic centipede-style gameplay
- Responsive controls (keyboard + touch)
- Progressive difficulty
- Score tracking
- Game over/restart functionality

## 🛠 Customization

### Update Colors/Styling
Edit the CSS variables in the `<style>` section:

```css
/* Change the gradient background */
background: linear-gradient(to bottom, #1e3a8a, #581c87, #1e3a8a);

/* Update accent colors */
color: #67e8f9; /* Cyan accents */
```

### Change the Lost ARI Image
Replace the `lost.gif` file or update the image source:

```javascript
// In the initLostAri() function
lostAri.src = './your-custom-image.gif';
```

### Modify Game Settings
Adjust game constants at the top of the script:

```javascript
const GAME_WIDTH = 800;    // Canvas width
const GAME_HEIGHT = 600;   // Canvas height
const PLAYER_SIZE = 20;    // Player size
// etc...
```

### Update Messaging
Change the text content in the HTML:

```html
<p class="subtitle">Your custom 404 message here</p>
<p class="quote">"Your custom platypus quote" - Character Name</p>
```

## 📱 Mobile Support

The page includes:
- Touch-friendly controls
- Responsive canvas scaling
- Mobile-optimized button sizes
- Viewport meta tag for proper scaling

## 🔒 No Dependencies

This 404 page uses:
- Pure HTML5 Canvas for the game
- Vanilla JavaScript (no frameworks)
- Embedded CSS (no external stylesheets)
- No CDN dependencies
- No build process required

## 🌊 AquaPrime Branding

Maintains the AquaPrime aesthetic with:
- Ocean gradient backgrounds
- Platypus character theming
- "Digital ocean" messaging
- Cyan/blue color scheme
- Nautical navigation metaphors

## 📊 Browser Support

Works in all modern browsers:
- Chrome/Edge (Canvas 2D)
- Firefox (Canvas 2D)
- Safari (Canvas 2D)
- Mobile browsers

## 🚀 Performance

- Loads instantly (single file)
- 60fps game loop
- Optimized collision detection
- Memory-efficient rendering
- No external API calls

## 💡 Tips

1. **Test the secret game** - Click the "404" badge 7 times
2. **Customize for your site** - Update colors and messaging
3. **Add analytics** - Track 404s and game engagement
4. **Consider CDN** - Host the file on CDN for better performance

Enjoy your portable AquaPrime 404 page! 🎮🌊